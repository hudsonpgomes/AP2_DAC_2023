package bean;

import static util.MessageUTIL.erro;
import static util.MessageUTIL.sucesso;

import java.util.List;

import javax.faces.bean.ManagedBean;

import dao.IncidenteDao;
import entidades.Incidente;

@ManagedBean(name = "incidenteBean")
public class IncidenteBean {
	
	private Incidente incidente = new Incidente();
	private List<Incidente> lista;
	
	public String salvar() {
		try {
			IncidenteDao.salvar(incidente);
			sucesso("Sucesso", "Denuncia salva com sucesso");
			incidente = new Incidente();
		} catch (Exception e) {
			erro("Erro", "Erro ao salvar" + e);
		}
		return null;
	}
	public String deletar() {
		IncidenteDao.deletar(incidente);
		sucesso("Sucesso", "Denuncia deletada ");
		lista = IncidenteDao.listarTodos();
		return null;
	}
	public Incidente getIncidente() {
		return incidente;
	}
	public void setIncidente(Incidente incidente) {
		this.incidente = incidente;
	}
	public List<Incidente> getLista() {
		if(lista == null) {
			lista = IncidenteDao.listarTodos();
		}
		return lista;
	}
	public void setLista(List<Incidente> lista) {
		this.lista = lista;
	}
	
}
