package entidades;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Incidente {

	@Id
	@GeneratedValue
	private Integer id;
	@Column(name = "Nome da vítima")
	private String nomeDaVitima;
	@Column(name = "Sexo da vítima")
	private String sexoDaVitima;
	@Column(name = "Idade da vítima")
	private Integer idadeDaVitima;
	@Column(name = "Série/Turno da vítima")
	private String serieTurnoDaVitima;
	@Column(name = "Enderço da vítima")
	private String enderecoDaVitima;
	
	@Column(name = "Nome do agressor")
	private String nomeDoAgressor;
	@Column(name = "Sexo do agressor")
	private String sexoDoAgressor;
	@Column(name = "Idade do agressor")
	private Integer idadeDoAgressor;
	@Column(name = "Grau de Parentesco do Agressor")
	private String grauParentescoDoAgressor;
	@Column(name = "Ocupação do agressor")
	private String ocupacaoDoAgressor;
	@Column(name = "Raca/Cor do agressor")
	private String racaCorDoAgressor;
	@Column(name = "Gênero do agressor")
	private String identidadeGeneroDoAgressor;
	@Column(name = "Orientação sexual do agressor")
	private String orientacaoSexualDoAgressor;
	@Column(name = "Escolaridade do agressor")
	private Integer escolaridadeDoAgressor;
	
	@Column(name = "Relato do incidente")
	private String relatoDoIncidente;
	@Column(name = "Violação de direito")
	private String violacaoDeDireito;
	@Column(name = "Providencias")
	private String providencias;
	
	@Column(name = "Data de registro")
	@Temporal(TemporalType.TIMESTAMP)
	private Date data;
	
	@PrePersist
    protected void onCreate() {
        data = new Date();
    }

	public String getNomeDaVitima() {
		return nomeDaVitima;
	}

	public void setNomeDaVitima(String nomeDaVitima) {
		this.nomeDaVitima = nomeDaVitima;
	}

	public String getSexoDaVitima() {
		return sexoDaVitima;
	}

	public void setSexoDaVitima(String sexoDaVitima) {
		this.sexoDaVitima = sexoDaVitima;
	}

	public Integer getIdadeDaVitima() {
		return idadeDaVitima;
	}

	public void setIdadeDaVitima(Integer idadeDaVitima) {
		this.idadeDaVitima = idadeDaVitima;
	}

	public String getSerieTurnoDaVitima() {
		return serieTurnoDaVitima;
	}

	public void setSerieTurnoDaVitima(String serieTurnoDaVitima) {
		this.serieTurnoDaVitima = serieTurnoDaVitima;
	}

	public String getEnderecoDaVitima() {
		return enderecoDaVitima;
	}

	public void setEnderecoDaVitima(String enderecoDaVitima) {
		this.enderecoDaVitima = enderecoDaVitima;
	}

	public String getNomeDoAgressor() {
		return nomeDoAgressor;
	}

	public void setNomeDoAgressor(String nomeDoAgressor) {
		this.nomeDoAgressor = nomeDoAgressor;
	}

	public String getSexoDoAgressor() {
		return sexoDoAgressor;
	}

	public void setSexoDoAgressor(String sexoDoAgressor) {
		this.sexoDoAgressor = sexoDoAgressor;
	}

	public Integer getIdadeDoAgressor() {
		return idadeDoAgressor;
	}

	public void setIdadeDoAgressor(Integer idadeDoAgressor) {
		this.idadeDoAgressor = idadeDoAgressor;
	}

	public String getGrauParentescoDoAgressor() {
		return grauParentescoDoAgressor;
	}

	public void setGrauParentescoDoAgressor(String grauParentescoDoAgressor) {
		this.grauParentescoDoAgressor = grauParentescoDoAgressor;
	}

	public String getOcupacaoDoAgressor() {
		return ocupacaoDoAgressor;
	}

	public void setOcupacaoDoAgressor(String ocupacaoDoAgressor) {
		this.ocupacaoDoAgressor = ocupacaoDoAgressor;
	}

	public String getRacaCorDoAgressor() {
		return racaCorDoAgressor;
	}

	public void setRacaCorDoAgressor(String racaCorDoAgressor) {
		this.racaCorDoAgressor = racaCorDoAgressor;
	}

	public String getIdentidadeGeneroDoAgressor() {
		return identidadeGeneroDoAgressor;
	}

	public void setIdentidadeGeneroDoAgressor(String identidadeGeneroDoAgressor) {
		this.identidadeGeneroDoAgressor = identidadeGeneroDoAgressor;
	}

	public String getOrientacaoSexualDoAgressor() {
		return orientacaoSexualDoAgressor;
	}

	public void setOrientacaoSexualDoAgressor(String orientacaoSexualDoAgressor) {
		this.orientacaoSexualDoAgressor = orientacaoSexualDoAgressor;
	}

	public Integer getEscolaridadeDoAgressor() {
		return escolaridadeDoAgressor;
	}

	public void setEscolaridadeDoAgressor(Integer escolaridadeDoAgressor) {
		this.escolaridadeDoAgressor = escolaridadeDoAgressor;
	}

	public String getRelatoDoIncidente() {
		return relatoDoIncidente;
	}

	public void setRelatoDoIncidente(String relatoDoIncidente) {
		this.relatoDoIncidente = relatoDoIncidente;
	}

	public String getViolacaoDeDireito() {
		return violacaoDeDireito;
	}

	public void setViolacaoDeDireito(String violacaoDeDireito) {
		this.violacaoDeDireito = violacaoDeDireito;
	}

	public String getProvidencias() {
		return providencias;
	}

	public void setProvidencias(String providencias) {
		this.providencias = providencias;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
}
